using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement1 : MonoBehaviour {

	public CharacterController controller;
	
	public Animator animator;
	public float runSpeed = 40f;
	private int landingCounter = -1;
	float horizontalMove = 0f;
	bool jump = false;
	bool crouch = false;
	private bool canAttack = true;
	public Transform enemy;
	public Transform player;
	private int healthE = 10;
	

	// Update is called once per frame
	
	void Update () {

		

		horizontalMove = Input.GetAxisRaw("Horizontal1") * runSpeed;

		animator.SetFloat("Speed", Mathf.Abs(horizontalMove));


		if(Input.GetMouseButtonDown(0)){
			 healthE --;
			 if(healthE <= 0){
				animator.SetBool("GameOver", true);
			 }
		}
		

		if (Input.GetButtonDown("Jump1"))
		{
			animator.SetBool("Jumping", true);
			jump = true;
		}

		if (Input.GetButtonDown("Crouch"))
		{
			crouch = true;
		} else if (Input.GetButtonUp("Crouch"))
		{
			crouch = false;
		}

	}

	public void onLanding() {
		landingCounter ++;
		if(landingCounter % 2 == 0){
			animator.SetBool("Jumping", false);
			Debug.Log("Landed");
		}
		
		
	}

	void FixedUpdate ()
	{
		// Move our character
		controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);
		jump = false;

	}
}